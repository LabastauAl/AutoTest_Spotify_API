package testData;

public class InputDataConstants {
    public static final String AUTHORIZATION_URL = "https://accounts.spotify.com/authorize";
    public static final String SCOPE = "playlist-modify-private playlist-read-private";
    public static final String APP_REDIRECT_URI = "https://oauth.pstmn.io/v1/browser-callback";

    public static final String APP_CLIENT_ID = "put your CLIENT ID here";
    public static final String APP_CLIENT_SECRET = "put your CLIENT SECRET here";

    public static final String SPOTIFY_ACCOUNT_EMAIL = "put your EMAIL here";
    public static final String SPOTIFY_ACCOUNT_PASSWORD = "put your PASSWORD here";


}
