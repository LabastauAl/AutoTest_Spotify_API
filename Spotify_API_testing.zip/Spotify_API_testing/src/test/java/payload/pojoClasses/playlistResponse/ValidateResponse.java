package payload.pojoClasses.playlistResponse;

import com.google.gson.Gson;
import testData.JsonConverter;

import java.util.ArrayList;
import java.util.List;

public class ValidateResponse {
    public static void main(String[] args) {
        ResponseBody responseBody = new ResponseBody();

        SongItems item1 = new SongItems();
        Track track1 = new Track();
        Album album1 = new Album();
        album1.setName("ALBUM 1");
        Artists artist1_1 = new Artists();
        artist1_1.setName("Metal Band 1-1");
        Artists artist1_2 = new Artists();
        artist1_2.setName("Metal Band 1-2");
        List<Artists> artistsList = new ArrayList<>();
        artistsList.add(0, artist1_1);
        artistsList.add(1, artist1_2);
        track1.setAlbum(album1);
        track1.setArtists(artistsList);
        track1.setName("Song 1");
        item1.setTrack(track1);


        SongItems item2 = new SongItems();
        Track track2 = new Track();
        Album album2 = new Album();
        album2.setName("ALBUM 2");
        Artists artist2 = new Artists();
        artist2.setName("Metal Band 2");
        List<Artists> artistsList2 = new ArrayList<>();
        artistsList2.add(0, artist2);
        track2.setAlbum(album2);
        track2.setArtists(artistsList2);
        track2.setName("Song 2");
        item2.setTrack(track2);

        SongItems item3 = new SongItems();
        Track track3 = new Track();
        Album album3 = new Album();
        album3.setName("ALBUM 3");
        Artists artist3_1 = new Artists();
        artist3_1.setName("Metal Band 3-1");
        Artists artist3_2 = new Artists();
        artist3_2.setName("Metal Band 3-2");
        Artists artist3_3 = new Artists();
        artist3_3.setName("Metal Band 3-3");
        List<Artists> artistsList3 = new ArrayList<>();
        artistsList3.add(0, artist3_1);
        artistsList3.add(1, artist3_2);
        artistsList3.add(2, artist3_3);
        track3.setAlbum(album3);
        track3.setArtists(artistsList3);
        track3.setName("Song 3");
        item3.setTrack(track3);


        List<SongItems> itemsList = new ArrayList<>();
        itemsList.add(0, item1);
        itemsList.add(1, item2);
        itemsList.add(2, item3);
        responseBody.setItems(itemsList);

        System.out.println(responseBody.getItems().size());

        Gson gson = new Gson();
        String json = gson.toJson(responseBody);
        JsonConverter.stringToJson(json).prettyPrint();

    }
}
