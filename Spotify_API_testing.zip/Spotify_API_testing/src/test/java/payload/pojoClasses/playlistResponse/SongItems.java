package payload.pojoClasses.playlistResponse;

import java.util.List;

public class SongItems {
    private Track track;

    public Track getTrack() {
        return track;
    }

    public void setTrack(Track track) {
        this.track = track;
    }
}
