package payload.pojoClasses.playlistResponse;

import java.util.List;

public class ResponseBody {
    private List<SongItems> items;

    public List<SongItems> getItems() {
        return items;
    }

    public void setItems(List<SongItems> items) {
        this.items = items;
    }
}
