package payload.pojoClasses.playlistResponse;

public class Artists {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
