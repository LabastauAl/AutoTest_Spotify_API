package payload.pojoClasses.removeRequest;

import java.util.List;

public class RequestBody {
    private List<Tracks> tracks;
    private String snapshot_id;

    public List<Tracks> getTracks() {
        return tracks;
    }

    public void setTracks(List<Tracks> tracks) {
        this.tracks = tracks;
    }

    public String getSnapshot_id() {
        return snapshot_id;
    }

    public void setSnapshot_id(String snapshot_id) {
        this.snapshot_id = snapshot_id;
    }


}
