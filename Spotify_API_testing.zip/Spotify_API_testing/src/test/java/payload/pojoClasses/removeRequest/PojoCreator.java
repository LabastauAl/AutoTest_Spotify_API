package payload.pojoClasses.removeRequest;

import java.util.ArrayList;
import java.util.List;

public class PojoCreator {
    public static RequestBody requestBody(String song1Id, String song2Id, String song3Id, String snapshotId){
        Tracks track1 = new Tracks();
        track1.setUri(song1Id);
        Tracks track2 = new Tracks();
        track2.setUri(song2Id);
        Tracks track3 = new Tracks();
        track3.setUri(song3Id);
        List<Tracks> tracks = new ArrayList<>();
        tracks.add(0, track1);
        tracks.add(1, track2);
        tracks.add(2, track3);

        RequestBody requestBody = new RequestBody();
        requestBody.setTracks(tracks);
        requestBody.setSnapshot_id(snapshotId);

        return requestBody;
    }

}
