package payload.pojoClasses.removeRequest;

public class Tracks {
    private String uri;

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = "spotify:track:" + uri;
    }
}
