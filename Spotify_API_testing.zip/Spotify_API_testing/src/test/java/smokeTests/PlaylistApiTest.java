package smokeTests;

import com.google.gson.Gson;
import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;

import io.restassured.parsing.Parser;
import org.openqa.selenium.WebDriver;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.SpotifyLoginPage;
import payload.pojoClasses.playlistResponse.ResponseBody;
import payload.pojoClasses.removeRequest.PojoCreator;
import payload.pojoClasses.removeRequest.RequestBody;
import testData.JsonConverter;
import utils.Base64coder;
import utils.WebDriverSingleton;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static testData.InputDataConstants.*;

public class PlaylistApiTest {

    protected static WebDriver driver;
    protected static String spotifyAuthorizationPageUri;
    protected static String authorizationCode;
    protected static SpotifyLoginPage spotifyLoginPage;
    protected static String accessToken, userId, userName, createdPlaylistId, snapshotId;
    protected static int amountOfSongsInPlaylist;

    @BeforeTest
    public static void startActions() {
        driver = WebDriverSingleton.getWebDriver();
        spotifyAuthorizationPageUri = AUTHORIZATION_URL + "?" + "client_id=" + APP_CLIENT_ID + "&response_type=code" + "&scope=" + SCOPE + "&redirect_uri=" + APP_REDIRECT_URI;
        spotifyLoginPage = new SpotifyLoginPage(driver);
    }

    @BeforeClass
    public static void enterToTheSpotifyAccount() throws InterruptedException {
        driver.get(spotifyAuthorizationPageUri);
        spotifyLoginPage.setLogin(SPOTIFY_ACCOUNT_EMAIL);
        spotifyLoginPage.setPassword(SPOTIFY_ACCOUNT_PASSWORD);
        spotifyLoginPage.checkBoxControl();
        spotifyLoginPage.loginEnter();
        Thread.sleep(2000);
    }

    @Test(priority = 1)
    public static void getAuthorizationCode() {
        Assert.assertTrue(driver.getCurrentUrl().contains(APP_REDIRECT_URI));
        authorizationCode = driver.getCurrentUrl().split("code=")[1];
        System.out.println(driver.getCurrentUrl());
        System.out.println(authorizationCode);
    }

    @Test(description = "Exchange authorization code to access token", priority = 2)
    public static void getAccessToken() {
        RestAssured.baseURI = "https://accounts.spotify.com";
        String response = given().log().all().header("Content-Type", "application/x-www-form-urlencoded").
                header("Authorization", "Basic " + Base64coder.encodeToBase64(APP_CLIENT_ID, APP_CLIENT_SECRET)).
                formParam("grant_type", "authorization_code").
                formParam("code", authorizationCode).
                formParam("redirect_uri", APP_REDIRECT_URI).
                when().post("/api/token").
                then().log().all().assertThat().statusCode(200).extract().response().asString();

        accessToken = JsonConverter.stringToJson(response).getString("access_token");

    }

    @Test(description = "Get detailed profile information about current user", priority = 3, enabled = true)
    public static void getCurrentUserProfile() {
        baseURI = "https://api.spotify.com/v1";
        String response = given().header("Authorization", "Bearer " + accessToken).
                when().get("/me").
                then().log().all().assertThat().statusCode(200).extract().response().asString();
        userId = JsonConverter.stringToJson(response).getString("id");
        userName = JsonConverter.stringToJson(response).getString("display_name");
    }

    @Test(description = "Create a playlist for a user", priority = 4)
    public static void createPlaylist() {
        String response = given().header("Authorization", "Bearer " + accessToken).
                header("Content-Type", "application/json").
                body("{\n" +
                        "  \"name\": \"Thrash-Metal playlist API" + ((int) (Math.random() * 2023)) + "\",\n" +
                        "  \"description\": \"Playlist was created via API\",\n" +
                        "  \"public\": false,\n" +
                        "  \"collaborative\": false\n" +
                        "}").
                when().post("/users/" + userId + "/playlists").then().log().all().assertThat().statusCode(201).extract().response().asString();
        createdPlaylistId = JsonConverter.stringToJson(response).getString("id");
    }

    @Test(description = "Add one or more items to Playlist. Adding 5 songs into playlist which created in previous method", priority = 5)
    public static void addItemsToPlaylist() throws IOException {
        given().log().all().header("Authorization", "Bearer " + accessToken).
                header("Content-Type", "application/json").
                body(new String(Files.readAllBytes(Paths.get("src/test/java/payload/addSongs.json"))))
                .when().post("/playlists/" + createdPlaylistId + "/tracks")
                .then().log().all().assertThat().statusCode(201);
    }

    @Test(description = "Get a list of the playlists of a user", priority = 6)
    public static void getUserPlaylists() {
        int playlistsAmount;
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                when().get("/users/" + userId + "/playlists").
                then().log().headers().assertThat().statusCode(200).extract().response().asString();
        playlistsAmount = JsonConverter.stringToJson(response).getInt("items.size()");
        System.out.println("Playlists amount of " + userName + ":\t" + playlistsAmount);

        for (int i = 0; i < playlistsAmount; i++) {
            System.out.println(JsonConverter.stringToJson(response).getString("items[" + i + "].name") + "\tID "
                    + JsonConverter.stringToJson(response).getString("items[" + i + "].id"));
        }
    }

    @Test(description = "Get playlist owned by a user. Show songs from created playlist", priority = 7)
    public static void getPlaylist() {
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("fields", "items(track(name,album(name)))")
                .when().get("/playlists/" + createdPlaylistId + "/tracks")
                .then().log().all().assertThat().statusCode(200).extract().response().asString();
        amountOfSongsInPlaylist = JsonConverter.stringToJson(response).getInt("items.size()");
        System.out.println("Amount of songs in current Playlist:\t" + amountOfSongsInPlaylist);
        Assert.assertEquals(amountOfSongsInPlaylist, 5);
    }

    @Test(description = "Add one or more items to Playlist. Adding two more songs to the created playlist", priority = 8)
    public static void addItemsToPlaylistQueryParams() {
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("position", amountOfSongsInPlaylist).
                queryParam("uris", "spotify:track:3pKsUMqpVr4ZJ13Mm91Xig,spotify:track:5awljpWNO5TpXCyjpvCBbs")
                .when().post("/playlists/" + createdPlaylistId + "/tracks")
                .then().log().all().assertThat().statusCode(201).extract().response().asString();
        snapshotId = JsonConverter.stringToJson(response).getString("snapshot_id");
    }

    @Test(description = "Get playlist owned by a user. Checking of song amount after adding new songs", priority = 9)
    public static void getPlaylist2() {
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("fields", "items(track(name,album(name)))")
                .when().get("/playlists/" + createdPlaylistId + "/tracks")
                .then().log().all().assertThat().statusCode(200).extract().response().asString();
        amountOfSongsInPlaylist = JsonConverter.stringToJson(response).getInt("items.size()");
        System.out.println("Amount of songs in current Playlist:\t" + amountOfSongsInPlaylist);
        Assert.assertEquals(amountOfSongsInPlaylist, 7);
    }

    @Test(description = "Remove one or more items from a user's playlist. Delete 3 songs from created playlist", priority = 10)
    public static void removePlaylistItems() {
        RequestBody requestBody = PojoCreator.requestBody("77xmDupCWuKQ9lz8hSUszC", "3pKsUMqpVr4ZJ13Mm91Xig", "5PFhkQbjJge1h8k7wE1K5U", snapshotId);
        given().log().all().header("Authorization", "Bearer " + accessToken).
                header("Content-Type", "application/json").
//                body("{\n" +
//                        "    \"tracks\": [\n" +
//                        "        {\n" +
//                        "            \"uri\": \"spotify:track:5PFhkQbjJge1h8k7wE1K5U\"\n" +
//                        "        }\n" +
//                        "    ],\n" +
//                        "    \"snapshot_id\": \"" + snapshotId +"\"\n" +
//                        "}")
        body(requestBody)
                .when().delete("/playlists/" + createdPlaylistId + "/tracks")
                .then().log().all();

    }

    @Test(description = "Get playlist owned by a user", priority = 11)
    public static void getPlaylist3() {
        ResponseBody response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("fields", "items(track(name,album(name),artists(name)))").
                expect().defaultParser(Parser.JSON)
                .when().get("/playlists/" + createdPlaylistId + "/tracks").as(ResponseBody.class);
        Gson gson = new Gson();
        String json = gson.toJson(response);
        JsonConverter.stringToJson(json).prettyPrint();
        amountOfSongsInPlaylist = response.getItems().size();
        System.out.println("Amount of songs in current Playlist:\t" + amountOfSongsInPlaylist);
        Assert.assertEquals(amountOfSongsInPlaylist, 4, "Amount of songs doesn't match expected!!! ");
    }

    @AfterTest(enabled = true)
    public static void endOfSession() {
        WebDriverSingleton.quitDriver();
    }
}
