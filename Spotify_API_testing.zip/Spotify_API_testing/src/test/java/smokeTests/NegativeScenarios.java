package smokeTests;

import io.restassured.RestAssured;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjects.SpotifyLoginPage;
import testData.JsonConverter;
import utils.Base64coder;
import utils.WebDriverSingleton;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static testData.InputDataConstants.*;
import static testData.InputDataConstants.APP_REDIRECT_URI;

public class NegativeScenarios {
    protected static WebDriver driver;
    protected static String spotifyAuthorizationPageUri;
    protected static String authorizationCode;
    protected static SpotifyLoginPage spotifyLoginPage;
    protected static String accessToken, userId, userName;

    @BeforeTest(enabled = true)
    public static void startActions() {
        driver = WebDriverSingleton.getWebDriver();
        spotifyAuthorizationPageUri = AUTHORIZATION_URL + "?" + "client_id=" + APP_CLIENT_ID + "&response_type=code" + "&scope=" + SCOPE + "&redirect_uri=" + APP_REDIRECT_URI;
        spotifyLoginPage = new SpotifyLoginPage(driver);
    }

    @BeforeClass(enabled = true)
    public static void enterToTheSpotifyAccount() throws InterruptedException {
        driver.get(spotifyAuthorizationPageUri);
        spotifyLoginPage.setLogin(SPOTIFY_ACCOUNT_EMAIL);
        spotifyLoginPage.setPassword(SPOTIFY_ACCOUNT_PASSWORD);
        spotifyLoginPage.checkBoxControl();
        spotifyLoginPage.loginEnter();
        Thread.sleep(2000);
    }

    @Test(priority = 1, enabled = true)
    public static void getAuthorizationCode() {
        authorizationCode = driver.getCurrentUrl().split("code=")[1];
        System.out.println(driver.getCurrentUrl());
        System.out.println(authorizationCode);
    }

    @Test(description = "Exchange authorization code to access token", priority = 2, enabled = true)
    public static void getAccessToken() {
        RestAssured.baseURI = "https://accounts.spotify.com";
        String response = given().log().all().header("Content-Type", "application/x-www-form-urlencoded").
                header("Authorization", "Basic " + Base64coder.encodeToBase64(APP_CLIENT_ID, APP_CLIENT_SECRET)).
                formParam("grant_type", "authorization_code").
                formParam("code", authorizationCode).
                formParam("redirect_uri", APP_REDIRECT_URI).
                when().post("/api/token").
                then().log().all().assertThat().statusCode(200).extract().response().asString();

        accessToken = JsonConverter.stringToJson(response).getString("access_token");
    }

    @Test(description = "Get detailed profile information about current user", priority = 3, enabled = true)
    public static void getCurrentUserProfile() {
        baseURI = "https://api.spotify.com/v1";
        String response = given().header("Authorization", "Bearer " + accessToken).
                when().get("/me").
                then().log().all().assertThat().statusCode(200).extract().response().asString();
        userId = JsonConverter.stringToJson(response).getString("id");
        userName = JsonConverter.stringToJson(response).getString("display_name");
    }

    @Test(description = "Get playlist owned by a user. Trying to show songs from playlist with wrong Id", priority = 4)
    public static void getPlaylist() {
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("fields", "items(track(name,album(name)))")
                .when().get("/playlists/" + "SomePlaylistId" + "/tracks")
                .then().log().all().assertThat().statusCode(404).extract().response().asString();
        String errorMessage = JsonConverter.stringToJson(response).getString("error.message");
        Assert.assertEquals(errorMessage, "Invalid playlist Id");
    }

    @Test(description = "Attempt to add some songs to the private playlist from another account", priority = 5)
    public static void addSongsToPrivatePlaylist() {
        String response = given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("uris", "spotify:track:3pKsUMqpVr4ZJ13Mm91Xig,spotify:track:5awljpWNO5TpXCyjpvCBbs")
                .when().post("/playlists/" + "3cEYpjA9oz9GiPac4AsH4n" + "/tracks")
                .then().log().all().assertThat().statusCode(403).extract().response().asString();
        String errorMessage = JsonConverter.stringToJson(response).getString("error.message");
        Assert.assertEquals(errorMessage, "Insufficient client scope");
    }

    @Test(description = "Attempt to add two more songs with wrong IDs to the existing playlist", priority = 6)
    public static void addSongsWithWrongID() {
        String response = given().header("Authorization", "Bearer " + accessToken).
                when().get("/users/" + userId + "/playlists").
                then().extract().response().asString();
        String playlistId = JsonConverter.stringToJson(response).getString("items[0].id");
        System.out.println("The ID of testing playlist:\t" + playlistId);

        given().log().all().header("Authorization", "Bearer " + accessToken).
                queryParam("uris", "spotify:track:SomeSong1wrongID,spotify:track:SomeSong2wrongID")
                .when().post("/playlists/" + playlistId + "/tracks")
                .then().log().all().assertThat().statusCode(400).extract().response().asString();
    }

    @AfterTest(enabled = true)
    public static void endOfSession() {
        WebDriverSingleton.quitDriver();
    }

}
