package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.time.Duration;

public class WebDriverSingleton {
    private static WebDriver driver = null;
    private static final String BROWSER_TYPE = "Chrome";
    private static final String CHROME_DRIVER_PATH = "put_the_path_to_webdriver_chromedriver_here\\chromedriver.exe";
    private static final String FIREFOX_DRIVER_PATH = "Path_to_FireFox_driver";

    private WebDriverSingleton() {
    }

    private static WebDriver createDriver() {
        switch (BROWSER_TYPE) {
            case "Chrome":
                System.setProperty("webdriver.chrome.driver", CHROME_DRIVER_PATH);
                driver = new ChromeDriver();
                break;

            case "FireFox":
                System.setProperty("webdriver.firefox.driver", FIREFOX_DRIVER_PATH);
                driver = new FirefoxDriver();
                break;

            default:
                throw new IllegalArgumentException("Value of browser type " + BROWSER_TYPE + " is incorrect");
        }
        return driver;
    }

    public static WebDriver getWebDriver(){
        if(driver == null){
            driver = createDriver();

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
            driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(10));
            driver.manage().window().maximize();
        }
        return driver;
    }

    public static void quitDriver(){
        if (driver!=null) {
            driver.quit();
            driver = null;
        }
    }

}
