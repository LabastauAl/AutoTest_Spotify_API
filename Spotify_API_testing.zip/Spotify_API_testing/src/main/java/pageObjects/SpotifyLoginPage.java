package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SpotifyLoginPage extends PageObjectBasics {
public SpotifyLoginPage(WebDriver driver){
    super(driver);
}

    @FindBy(xpath = "//input[@id='login-username']")
    private WebElement loginField;
    @FindBy(xpath = "//input[@id='login-password']")
    private WebElement passwordField;
    @FindBy(xpath = "//button[@id='login-button']")
    private WebElement loginButton;
    @FindBy(xpath = "//input[@data-testid='login-remember']/following-sibling::span")     //*** old xpath ---> //label[@for='login-remember']/span
    private WebElement loginCheckbox;

    @FindBy(xpath = "//div[@data-encore-id='banner']")
    private WebElement warningBanner;


    public void setLogin(String loginEmail) {
        loginField.clear();
        loginField.sendKeys(loginEmail);
    }

    public void setPassword(String loginPassword) {
        passwordField.clear();
        passwordField.sendKeys(loginPassword);
    }

    public void checkBoxControl() {
        loginCheckbox.click();
    }

    public void loginEnter() {
        loginButton.click();
    }

}
