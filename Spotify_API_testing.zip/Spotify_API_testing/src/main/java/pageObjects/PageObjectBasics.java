package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class PageObjectBasics {
    protected static WebDriver driver;

    protected PageObjectBasics(WebDriver driver) {
        if (this.driver == null)
            this.driver = driver;
        PageFactory.initElements(driver, this);
    }
}
