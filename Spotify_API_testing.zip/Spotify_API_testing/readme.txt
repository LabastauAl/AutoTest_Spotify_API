Spotify_API_Testing tool was created for learning purposes only and is not a complete framework for automating testing or any works with websites.

This software solution is designed to automate the operations with some open APIs provided by the music service according to pre-planned scenarios.
Spotify_AP_Testing tool was developed and runs using the IntelliJ IDEA IDE. Performance in other development environments has not been tested.

Working with this solution requires presence of a registred account in the Spotify music service and registration of an application to obtain
access rights to the Spotify's APIs - "Client ID" and "Client Secret".

You cat create a new account on the page https://www.spotify.com/signup
After the ctreation of an account you should registrate new app on the page https://developer.spotify.com/dashboard
Description of how to registes an application is on the page https://developer.spotify.com/documentation/web-api/concepts/apps
Clarification - as a redirect URI you can use https://oauth.pstmn.io/v1/browser-callback
"Client ID" and "Client Secret" will be generated during the registration of an application

Necessary preconditions for the work of software solution:
The launch and operation of the application requires a web driver (the latest versions of webdrivers for the most popular browsers can be found at 
https://www.selenium.dev/downloads/) and for the correct operation it is necessary to specify the location of the webdriver on the computer - for this in the 
src/main/java/utils/WebDriverSingleton.java class, the constants CHROME_DRIVER_PATH and FIREFOX_DRIVER_PATH should be assigned the values of the address 
where the webdriver is located. 
It is also necessary to specify the correct location of the test.ng file in the launch and debug settings.
"Client ID" and "Client Secret", EMAIL specified during account registration and PASSWORD of an account should set as values of according constants
into src/test/java/testData/InputDataConstants.java class.